var img = document.getElementById('img');
document.onmousemove = function (e) {
    // 处理兼容性
    e = e || window.event;
    img.style.position = 'absolute';
    img.style.left = getPage(e).pageX + 'px';
    img.style.top = getPage(e).pageY + 'px';

}


//获取页面滚动出去的距离 并处理兼容性
function getScroll() {
    return {
        scrollTop: document.documentElement.scrollTop || document.body.scrollTop,
        scrollLeft: document.documentElement.scrollLeft || document.body.scrollLeft
    }
}


//获取鼠标在页面上的坐标
function getPage(e) {
    return {
        pageX: e.clientX + getScroll().scrollLeft,
        pageY: e.clientY + getScroll().scrollTop
    }
}
