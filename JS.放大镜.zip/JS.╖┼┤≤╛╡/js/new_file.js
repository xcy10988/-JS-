//获取需要元素
var box = document.getElementById('box');
var smallBox = box.children[0];
var bigBox = box.children[1];
var smallImg = smallBox.children[0];
var mask = smallBox.children[1];
var bigImg = bigBox.children[0];
//鼠标移到小盒子上,显示遮盖的层 显示大图
smallBox.onmouseenter = function () {
    mask.style.display = 'block';
    bigBox.style.display = 'block';
}
// onmouseenter 与 onmouseleave 这两个事件类似onmousemove和onmouseout 但是不会触发事件冒泡.
smallBox.onmouseleave = function () {
    mask.style.display = 'none';
    bigBox.style.display = 'none';
}
//鼠标在小盒子中移动时 遮盖层跟着鼠标移动
smallBox.onmousemove = function (e) {
    e = e || event;
    //获取鼠标在小盒子中的坐标
    var x = getPage(e).pageX - box.offsetLeft;
    var y = getPage(e).pageY - box.offsetTop;
    x = x - mask.offsetWidth / 2;
    y = y - mask.offsetHeight / 2;

    x = x < 0 ? 0 : x;
    y = y < 0 ? 0 : y;

    var maxX = smallBox.offsetWidth - mask.offsetWidth;
    var maxY = smallBox.offsetHeight - mask.offsetHeight;

    x = x > maxX ? maxX : x;
    y = y > maxY ? maxY : y;

    mask.style.left = x + 'px';
    mask.style.top = y + 'px';

    //显示对应的大图部分
    ///计算大图片的偏移
    //mask移动的距离/大图片移动的距离 = mask最大能移动的距离/大图片最大能移动的距离
    //大图片移动的距离=mask移动的距离 * 大图片最大能移动的距离/mask最大移动的距离
    //大图片最大能移动的距离
    var bigMaxX = bigImg.offsetWidth - bigBox.offsetWidth;
    var bigMaxY = bigImg.offsetHeight - bigBox.offsetHeight;
	
	var bigImgx = x * bigMaxX / maxX;
	var bigImgy = y * bigMaxY / maxY;	
	//负的  因为左边图片鼠标向下移的时候,右边大图应该向上移动
	bigImg.style.left = -bigImgx + 'px';
	bigImg.style.top = -bigImgy + 'px';
}
