﻿
//设置元素之间的内容
function setInnerText(element,content){
	//判断element是否支持innerText
	if(typeof element.innerText === 'string'){
		element.innerText = content;
	}else{
		element.textContent = content;
	}
}


// 获取min-max之间的随机整数
function getrandom(min,max){
	// max - 期望的最大值
	// min - 期望的最小值  	
 	min = Math.ceil(min);
 	max = Math.floor(max);
 	return  Math.floor(Math.random()*(max - min + 1)) + min;
}


//根据ID获取元素
function getElement(id){
	return document.getElementById(id);
}


//获取页面滚动出去的距离 并处理兼容性
function getScroll() {
    return {
        scrollTop: document.documentElement.scrollTop || document.body.scrollTop,
        scrollLeft: document.documentElement.scrollLeft || document.body.scrollLeft
    }
}

//获取鼠标在页面上的坐标
function getPage(e) {
    return {
        pageX: e.clientX + getScroll().scrollLeft,
        pageY: e.clientY + getScroll().scrollTop
    }
}
